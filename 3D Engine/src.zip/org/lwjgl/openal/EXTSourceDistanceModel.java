/*
 * Copyright LWJGL. All rights reserved.
 * License terms: http://lwjgl.org/license.php
 * MACHINE GENERATED FILE, DO NOT EDIT
 */
package org.lwjgl.openal;

/** bindings to AL_EXT_source_distance_model extension. */
public final class EXTSourceDistanceModel {

	/** AL_EXT_source_distance_model tokens. */
	public static final int AL_SOURCE_DISTANCE_MODEL = 0x200;

	private EXTSourceDistanceModel() {}

}